#include <string>
#include "MainManu.Class.hpp"

int main(void)
{
    MainManu *mainM = new MainManu();
    mainM->StartWindow();
    return 0;
}
